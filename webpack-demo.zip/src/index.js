// ./src/index.js

import createHeading from './heading.js'

import oboutClass from './about'

const heading = createHeading()

document.body.append(heading)


